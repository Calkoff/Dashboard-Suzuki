package com.example.dashboardbandit

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.*
import android.content.SharedPreferences
private var voltMin = 11.3f
private var voltMax = 15.0f
private var tempMin = 40f
private var tempMax = 100f

class MainActivity : AppCompatActivity() {

    private lateinit var bluetoothManager: BluetoothManager
    private val handler = Handler(Looper.getMainLooper())
    private var timeRunnable: Runnable? = null
    private var autoConnectRunnable: Runnable? = null
    private var lastGear = -2

    // UI элементы
    private lateinit var gearText: TextView
    private lateinit var voltageText: TextView
    private lateinit var tempText: TextView
    private lateinit var vcText: TextView
    private lateinit var timeText: TextView
    private lateinit var settingsButton: TextView
    private lateinit var btIndicator: TextView
    private lateinit var centerDisplay: TextView

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContentView(R.layout.activity_main)
        hideSystemUI()

        bluetoothManager = BluetoothManager.getInstance(this)
        bluetoothManager.init()
        prefs = getSharedPreferences("dashboard_prefs", MODE_PRIVATE)
        loadThresholds()
        // Находим все элементы
        gearText = findViewById(R.id.gearText)
        voltageText = findViewById(R.id.voltageText)
        tempText = findViewById(R.id.tempText)
        vcText = findViewById(R.id.vcText)
        timeText = findViewById(R.id.timeText)
        settingsButton = findViewById(R.id.settingsButton)
        btIndicator = findViewById(R.id.btIndicator)
        centerDisplay = findViewById(R.id.centerDisplay)

        // Обработчик нажатия на шестерёнку
        settingsButton.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        // Применяем шрифт Orbitor (положить orbitor.ttf в res/font/)
        try {
            val orbitorFont = resources.getFont(R.font.orbitor)
            gearText.typeface = orbitorFont
            voltageText.typeface = orbitorFont
            tempText.typeface = orbitorFont
            vcText.typeface = orbitorFont
            timeText.typeface = orbitorFont
        } catch (e: Exception) {
            // Шрифт пока не добавлен — используем стандартный
        }

        // Запрос разрешений
        requestPermissions()

        // Запуск авто-подключения
        startAutoConnect()

        // Запуск часов
        startClock()
    }

    private fun requestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val needRequest = permissions.any {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needRequest) {
            requestPermissions(permissions, 1)
        }
    }

    private fun startAutoConnect() {
        updateBtStatus("red")
        tryConnect()

        autoConnectRunnable = object : Runnable {
            override fun run() {
                if (!bluetoothManager.isConnected()) {
                    tryConnect()
                    handler.postDelayed(this, 5000) // Повтор каждые 5 сек
                }
            }
        }
        handler.postDelayed(autoConnectRunnable!!, 5000)
    }

    private fun tryConnect() {
        if (!bluetoothManager.isBluetoothEnabled()) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBtIntent)
            return
        }

        Thread {
            val device = bluetoothManager.findTargetDevice()
            if (device != null) {
                val success = bluetoothManager.connect(device)
                handler.post {
                    if (success) {
                        updateBtStatus("white")
                        bluetoothManager.startReading(
                            onDataReceived = { data ->
                                handler.post { processData(data) }
                                handler.post { updateBtStatus("green") }
                            },
                            onDisconnected = {
                                handler.post {
                                    updateBtStatus("red")
                                    resetUI()
                                    startAutoConnect()
                                }
                            }
                        )
                    }
                }
            }
        }.start()
    }

    private fun processData(rawData: String) {
        val lines = rawData.split("\n")
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isNotEmpty()) {
                val data = parseMotoData(trimmed)
                data?.let { updateUI(it) }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateUI(data: MotoData) {
        // Обновление Bluetooth статуса
        updateBtStatus("green")

        // === 1.1 ПЕРЕДАЧА ===
        val newGear = data.gear
        gearText.setBackgroundResource(R.drawable.cell_bg)

        when {
            newGear == -1 -> {
                gearText.text = "-"
                gearText.setTextColor(Color.WHITE)
                gearText.setBackgroundResource(R.drawable.cell_bg_error)
            }
            newGear == 0 -> {
                gearText.text = "N"
                gearText.setTextColor(Color.BLACK)
                gearText.setBackgroundColor(Color.parseColor("#4CAF50"))
            }
            newGear in 1..6 -> {
                gearText.text = newGear.toString()
                gearText.setTextColor(Color.WHITE)
            }
        }

        // Анимация передачи в центре
        if (newGear != lastGear && newGear in 0..6) {
            showGearInCenter(newGear)
        }
        lastGear = newGear

        // === 1.2 НАПРЯЖЕНИЕ ===
        voltageText.setBackgroundResource(R.drawable.cell_bg)
        if (data.voltage < 0) {
            voltageText.text = "-"
            voltageText.setTextColor(Color.WHITE)
            voltageText.setBackgroundResource(R.drawable.cell_bg_error)
        } else {
            voltageText.text = "${String.format("%.1f", data.voltage)}V"
            if (data.voltage < voltMin || data.voltage > voltMax) {
                voltageText.setTextColor(Color.parseColor("#FF4444"))
                showAlertInCenter("VOLT ${String.format("%.1f", data.voltage)}V", isAlert = true)
            } else {
                voltageText.setTextColor(Color.WHITE)
            }
        }

        // === 1.3 ТЕМПЕРАТУРА ===
        tempText.setBackgroundResource(R.drawable.cell_bg)
        if (data.temperature < -50) {
            tempText.text = "-"
            tempText.setTextColor(Color.WHITE)
            tempText.setBackgroundResource(R.drawable.cell_bg_error)
        } else {
            tempText.text = "${data.temperature.toInt()}°"
            when {
                data.temperature < tempMin -> tempText.setTextColor(Color.parseColor("#4488FF"))
                data.temperature > tempMax -> {
                    tempText.setTextColor(Color.WHITE)
                    tempText.setBackgroundColor(Color.parseColor("#CC0000"))
                    showAlertInCenter("TEMP ${data.temperature.toInt()}°", isAlert = true)
                }
                else -> tempText.setTextColor(Color.WHITE)
            }
        }

        // === 3.1 VC ===
        vcText.setBackgroundResource(R.drawable.cell_bg)
        vcText.text = "VC"
        if (data.vc) {
            vcText.setTextColor(Color.BLACK)
            vcText.setBackgroundColor(Color.parseColor("#4CAF50"))
        } else {
            vcText.setTextColor(Color.WHITE)
        }
    }

    private var centerRunnable: Runnable? = null

    private fun showGearInCenter(gear: Int) {
        centerRunnable?.let { handler.removeCallbacks(it) }

        val text = if (gear == 0) "N" else gear.toString()
        centerDisplay.text = text
        centerDisplay.visibility = View.VISIBLE
        centerDisplay.setTextColor(Color.WHITE)
        centerDisplay.textSize = 120f

        centerRunnable = Runnable {
            centerDisplay.visibility = View.GONE
        }
        handler.postDelayed(centerRunnable!!, 1000)
    }

    private fun showAlertInCenter(text: String, isAlert: Boolean) {
        centerDisplay.text = text
        centerDisplay.textSize = 48f
        centerDisplay.setTextColor(if (isAlert) Color.parseColor("#FF4444") else Color.WHITE)
        centerDisplay.visibility = View.VISIBLE
    }

    fun hideCenterIfNormal() {
        // Скрываем, если не алерт (вызывать когда параметры вернулись в норму)
        centerDisplay.visibility = View.GONE
    }

    private fun updateBtStatus(state: String) {
        when (state) {
            "red" -> {
                btIndicator.setTextColor(Color.parseColor("#FF4444"))
            }
            "white" -> {
                btIndicator.setTextColor(Color.WHITE)
            }
            "green" -> {
                btIndicator.setTextColor(Color.parseColor("#4CAF50"))
            }
        }
    }

    private fun startClock() {
        timeRunnable = object : Runnable {
            override fun run() {
                val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                timeText.text = sdf.format(Date())
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(timeRunnable!!)
    }

    private fun hideSystemUI() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    override fun onDestroy() {
        super.onDestroy()
        timeRunnable?.let { handler.removeCallbacks(it) }
        autoConnectRunnable?.let { handler.removeCallbacks(it) }
        centerRunnable?.let { handler.removeCallbacks(it) }
        bluetoothManager.disconnect()
    }
    private fun resetUI() {
        gearText.text = "-"
        gearText.setTextColor(Color.WHITE)
        gearText.setBackgroundResource(R.drawable.cell_bg_error)

        voltageText.text = "-"
        voltageText.setTextColor(Color.WHITE)
        voltageText.setBackgroundResource(R.drawable.cell_bg_error)

        tempText.text = "-"
        tempText.setTextColor(Color.WHITE)
        tempText.setBackgroundResource(R.drawable.cell_bg_error)

        vcText.text = "VC"
        vcText.setTextColor(Color.WHITE)
        vcText.setBackgroundResource(R.drawable.cell_bg)
    }

    private fun loadThresholds() {
        voltMin = prefs.getString("volt_min", "11.3")?.toFloatOrNull() ?: 11.3f
        voltMax = prefs.getString("volt_max", "15.0")?.toFloatOrNull() ?: 15.0f
        tempMin = prefs.getString("temp_min", "40")?.toFloatOrNull() ?: 40f
        tempMax = prefs.getString("temp_max", "100")?.toFloatOrNull() ?: 100f
    }

}