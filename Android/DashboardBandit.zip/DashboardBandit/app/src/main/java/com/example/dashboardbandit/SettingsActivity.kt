package com.example.dashboardbandit

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var bluetoothManager: BluetoothManager
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    // ESP32
    private lateinit var bCoefficientInput: EditText
    private lateinit var voltCalibInput: EditText
    private lateinit var tempFilterInput: EditText
    private lateinit var voltFilterInput: EditText
    private lateinit var loadButton: Button
    private lateinit var saveButton: Button
    private lateinit var resetButton: Button

    // Пороги
    private lateinit var voltMinInput: EditText
    private lateinit var voltMaxInput: EditText
    private lateinit var tempMinInput: EditText
    private lateinit var tempMaxInput: EditText
    private lateinit var saveThresholdsButton: Button

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContentView(R.layout.activity_settings)

        bluetoothManager = BluetoothManager.getInstance(this)
        bluetoothManager.init()
        prefs = getSharedPreferences("dashboard_prefs", MODE_PRIVATE)

        // ESP32 элементы
        bCoefficientInput = findViewById(R.id.bCoefficientInput)
        voltCalibInput = findViewById(R.id.voltCalibInput)
        tempFilterInput = findViewById(R.id.tempFilterInput)
        voltFilterInput = findViewById(R.id.voltFilterInput)
        loadButton = findViewById(R.id.loadButton)
        saveButton = findViewById(R.id.saveButton)
        resetButton = findViewById(R.id.resetButton)

        // Пороги
        voltMinInput = findViewById(R.id.voltMinInput)
        voltMaxInput = findViewById(R.id.voltMaxInput)
        tempMinInput = findViewById(R.id.tempMinInput)
        tempMaxInput = findViewById(R.id.tempMaxInput)
        saveThresholdsButton = findViewById(R.id.saveThresholdsButton)

        statusText = findViewById(R.id.settingsStatusText)

        // Загружаем сохранённые пороги
        loadThresholds()

        // Кнопки ESP32
        loadButton.setOnClickListener { loadSettings() }
        saveButton.setOnClickListener { saveSettings() }
        resetButton.setOnClickListener { resetSettings() }

        // Кнопка сохранения порогов
        saveThresholdsButton.setOnClickListener { saveThresholds() }
    }

    private fun loadThresholds() {
        voltMinInput.setText(prefs.getString("volt_min", "11.3"))
        voltMaxInput.setText(prefs.getString("volt_max", "15.0"))
        tempMinInput.setText(prefs.getString("temp_min", "40"))
        tempMaxInput.setText(prefs.getString("temp_max", "100"))
    }

    private fun saveThresholds() {
        prefs.edit()
            .putString("volt_min", voltMinInput.text.toString())
            .putString("volt_max", voltMaxInput.text.toString())
            .putString("temp_min", tempMinInput.text.toString())
            .putString("temp_max", tempMaxInput.text.toString())
            .apply()
        statusText.text = "Пороги сохранены"
        statusText.setTextColor(Color.parseColor("#FFAA00"))
        Toast.makeText(this, "Пороги сохранены", Toast.LENGTH_SHORT).show()
    }

    // ====== Методы ESP32 (без изменений) ======

    private fun loadSettings() {
        if (!checkConnection()) return
        statusText.text = "Загрузка настроек..."
        statusText.setTextColor(Color.WHITE)

        Thread {
            val success = bluetoothManager.sendCommand("GET_SETTINGS")
            if (success) {
                Thread.sleep(300)
                val response = bluetoothManager.readResponse()
                handler.post {
                    if (response != null && response.startsWith("SETTINGS:")) {
                        parseSettings(response)
                        statusText.text = "Настройки загружены"
                        statusText.setTextColor(Color.parseColor("#4CAF50"))
                    } else {
                        statusText.text = "Ошибка: нет ответа"
                        statusText.setTextColor(Color.parseColor("#FF4444"))
                    }
                }
            } else {
                handler.post {
                    statusText.text = "Ошибка отправки"
                    statusText.setTextColor(Color.parseColor("#FF4444"))
                }
            }
        }.start()
    }

    private fun saveSettings() {
        if (!checkConnection()) return
        statusText.text = "Сохранение..."
        statusText.setTextColor(Color.WHITE)

        val b = bCoefficientInput.text.toString()
        val vc = voltCalibInput.text.toString()
        val tf = tempFilterInput.text.toString()
        val vf = voltFilterInput.text.toString()

        Thread {
            val commands = listOf("B=$b", "VOLT_CALIB=$vc", "TEMP_F=$tf", "VOLT_F=$vf")
            var allSuccess = true
            for (cmd in commands) {
                if (!bluetoothManager.sendCommand(cmd)) {
                    allSuccess = false
                    break
                }
                Thread.sleep(100)
            }
            handler.post {
                if (allSuccess) {
                    statusText.text = "Настройки сохранены"
                    statusText.setTextColor(Color.parseColor("#4CAF50"))
                    Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
                } else {
                    statusText.text = "Ошибка сохранения"
                    statusText.setTextColor(Color.parseColor("#FF4444"))
                }
            }
        }.start()
    }

    private fun resetSettings() {
        if (!checkConnection()) return
        statusText.text = "Сброс..."
        statusText.setTextColor(Color.WHITE)

        Thread {
            val success = bluetoothManager.sendCommand("RESET")
            if (success) {
                Thread.sleep(500)
                handler.post {
                    loadSettings()
                    Toast.makeText(this, "Настройки сброшены", Toast.LENGTH_SHORT).show()
                }
            } else {
                handler.post {
                    statusText.text = "Ошибка сброса"
                    statusText.setTextColor(Color.parseColor("#FF4444"))
                }
            }
        }.start()
    }

    private fun parseSettings(response: String) {
        try {
            val cleaned = response.removePrefix("SETTINGS:").trim()
            val pairs = cleaned.split(",")
            for (pair in pairs) {
                val (key, value) = pair.trim().split("=")
                when (key.trim()) {
                    "B" -> bCoefficientInput.setText(value.trim())
                    "VOLT_CALIB" -> voltCalibInput.setText(value.trim())
                    "TEMP_F" -> tempFilterInput.setText(value.trim())
                    "VOLT_F" -> voltFilterInput.setText(value.trim())
                }
            }
        } catch (e: Exception) {
            statusText.text = "Ошибка парсинга"
            statusText.setTextColor(Color.parseColor("#FF4444"))
        }
    }

    private fun checkConnection(): Boolean {
        if (!bluetoothManager.isConnected()) {
            statusText.text = "Нет подключения к ESP32"
            statusText.setTextColor(Color.parseColor("#FF4444"))
            return false
        }
        return true
    }
}