package com.example.dashboardbandit

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class BluetoothManager private constructor(private val context: Context) {

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private var isConnected = false
    private var readThread: Thread? = null

    companion object {
        @Volatile
        private var INSTANCE: BluetoothManager? = null

        fun getInstance(context: Context): BluetoothManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BluetoothManager(context.applicationContext).also { INSTANCE = it }
            }
        }

        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        const val TARGET_DEVICE_NAME = "MotoDashOBD"
    }

    fun init(): Boolean {
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager
        bluetoothAdapter = btManager?.adapter
        return bluetoothAdapter != null
    }

    fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter?.isEnabled == true
    }

    fun hasPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun findTargetDevice(): BluetoothDevice? {
        if (!hasPermissions()) return null
        val pairedDevices = bluetoothAdapter?.bondedDevices ?: emptySet()
        for (device in pairedDevices) {
            if (device.name == TARGET_DEVICE_NAME) return device
        }
        return null
    }

    fun connect(device: BluetoothDevice): Boolean {
        if (!hasPermissions()) return false
        try {
            bluetoothSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            bluetoothSocket?.connect()
            inputStream = bluetoothSocket?.inputStream
            outputStream = bluetoothSocket?.outputStream
            isConnected = true
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            disconnect()
            return false
        }
    }

    fun disconnect() {
        try {
            readThread?.interrupt()
            bluetoothSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            bluetoothSocket = null
            inputStream = null
            outputStream = null
            isConnected = false
            readThread = null
        }
    }

    fun startReading(onDataReceived: (String) -> Unit, onDisconnected: () -> Unit) {
        readThread = Thread {
            val buffer = ByteArray(1024)
            var bytes: Int
            while (isConnected && !Thread.currentThread().isInterrupted) {
                try {
                    bytes = inputStream?.read(buffer) ?: -1
                    if (bytes > 0) {
                        val data = String(buffer, 0, bytes)
                        onDataReceived(data)
                    } else if (bytes == -1) {
                        break
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    break
                }
            }
            if (isConnected) {
                disconnect()
                onDisconnected()
            }
        }
        readThread?.start()
    }

    fun sendCommand(command: String): Boolean {
        if (!isConnected || outputStream == null) return false
        return try {
            outputStream?.write((command + "\n").toByteArray())
            outputStream?.flush()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun readResponse(): String? {
        if (!isConnected || inputStream == null) return null
        return try {
            val buffer = ByteArray(256)
            val bytes = inputStream?.read(buffer) ?: -1
            if (bytes > 0) {
                String(buffer, 0, bytes).trim()
            } else null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun isConnected(): Boolean = isConnected
}