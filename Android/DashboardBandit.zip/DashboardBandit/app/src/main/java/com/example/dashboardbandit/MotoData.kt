package com.example.dashboardbandit

data class MotoData(
    val gear: Int,
    val temperature: Float,
    val voltage: Float,
    val vc: Boolean
)

fun parseMotoData(line: String): MotoData? {
    val gearMatch = Regex("GEAR:(-?\\d+)").find(line)
    val tempMatch = Regex("TEMP:([\\d.]+)").find(line)
    val voltMatch = Regex("VOLT:([\\d.]+)").find(line)
    val vcMatch = Regex("VC:(\\d+)").find(line)

    if (gearMatch == null || tempMatch == null || voltMatch == null || vcMatch == null) {
        return null
    }

    return MotoData(
        gear = gearMatch.groupValues[1].toInt(),
        temperature = tempMatch.groupValues[1].toFloat(),
        voltage = voltMatch.groupValues[1].toFloat(),
        vc = vcMatch.groupValues[1].toInt() == 1
    )
}